python3 . && python3 .
